package com.server.models;

public enum DeviceType {
  DECK,
  INCLINATION,
  ACCELERATION,
  NODO,
  CRACK
}
