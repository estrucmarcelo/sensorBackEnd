package com.server.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.server.models.Device;
import com.server.services.DeviceService;

@RestController
@RequestMapping("/api/devices")
public class DeviceController {
  @Autowired
  private DeviceService deviceService;

	@GetMapping("/all")
	public ResponseEntity<List<Device>> getDevices() {
		return deviceService.getDevices();
	}

  @GetMapping
	public ResponseEntity<Device> getDeviceById(@RequestParam("id") String id) {
		return deviceService.getDeviceById(id);
	}

	@PostMapping
	public ResponseEntity<Device> createDevice(@RequestBody Device deviceProps) {
		return deviceService.createDevice(deviceProps);
	}
}
