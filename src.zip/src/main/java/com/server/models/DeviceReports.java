package com.server.models;

import java.util.List;

import lombok.Getter;

public class DeviceReports {
  @Getter
  private int average;

  @Getter
  private int lowest;

  @Getter
  private int highest;

  @Getter
  private List<DeviceReport> reports;

  public DeviceReports(int average, int lowest, int highest, List<DeviceReport> reports) {
    this.average = average;
    this.lowest = lowest;
    this.highest = highest;
    this.reports = reports;
  }
}
