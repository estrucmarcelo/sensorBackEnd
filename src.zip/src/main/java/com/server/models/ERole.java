package com.server.models;

public enum ERole {
  ROLE_USER,
}
