package com.server.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.server.models.Device;
import com.server.repositories.DeviceRepository;

@Service
public class DeviceService {
  @Autowired
  private DeviceRepository deviceRepository;

  public ResponseEntity<List<Device>> getDevices() {
    List<Device> devices = deviceRepository.findAll(Sort.by(Sort.Direction.ASC, "createdAt"));

    return new ResponseEntity<List<Device>>(devices, HttpStatus.OK);
  }

  public ResponseEntity<Device> getDeviceById(String id) {
    Optional<Device> deviceFound = deviceRepository.findById(id);

    if (!deviceFound.isPresent()) {
      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    return new ResponseEntity<Device>(deviceFound.get(), HttpStatus.OK);
  }

  public ResponseEntity<Device> createDevice(@RequestBody Device deviceProps) {
    try {
      Device device = deviceRepository.save(new Device(deviceProps.getName(), deviceProps.getDescription()));

			return new ResponseEntity<>(device, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
  }
}
